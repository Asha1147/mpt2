package com.cg.bsa.bean;

public class ProductBean {
	
	private int productCode;
	private int quantity;
	private String productName;
	private String productCategory;
	private String productDescription;
	private int productPrice;
	private int lineTotal;
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(int lineTotal) {
		this.lineTotal = lineTotal;
	}
	@Override
	public String toString() {
		return "ProductBean [productCode=" + productCode + ", quantity=" + quantity + ", productName=" + productName
				+ ", productCategory=" + productCategory + ", productDescription=" + productDescription
				+ ", productPrice=" + productPrice + ", lineTotal=" + lineTotal + "]";
	}
	
	
	

}
