package com.cg.bsa.ui;

import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bsa.bean.ProductBean;
import com.cg.bsa.service.IProductService;
import com.cg.bsa.service.ProductServiceImpl;




public class Client {
	
	static Scanner scanner=new Scanner(System.in);
	static IProductService productService=null;
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception {
		
		 PropertyConfigurator.configure("resources//log4j.properties");
		while(true)
		{
			System.out.println("ABC BILLING SYSTEM");
			System.out.println("__________________");
			System.out.println("1.Genarate Bill");
			System.out.println("2.Exit");
			int option=scanner.nextInt();
			switch(option)
			{
			case 1:
				ProductBean bean=new ProductBean();
				productService=new ProductServiceImpl();
				System.out.println("Enter the Product Code :");
				bean.setProductCode(scanner.nextInt());
				System.out.println("1");
				bean=productService.getProductDetails(bean.getProductCode());
				
				if(bean!=null) {
					System.out.println(bean.getProductCode()+" "+bean.getProductName()+" "+bean.getProductCategory()+" "+bean.getProductDescription()+" "+bean.getProductPrice());
					}
					else
					{
						System.out.println("enter valid ID!");
					}
				
				
				System.out.println("Enter the Quantity :");
				int quantity=scanner.nextInt();
				if(quantity>0)
				{
				bean.setQuantity(quantity);
				}
				else
				{
					System.out.println("enter a valid number");
					quantity=scanner.nextInt();
				}
		
				productService.insertSalesDetails(bean);
				
				System.out.println("Product Name         :"+bean.getProductName());
				System.out.println("Prodcut Categry      :"+bean.getProductCategory());
				System.out.println("Product Descrpiotn   :"+bean.getProductDescription());
				System.out.println("Product price  		 :"+bean.getProductPrice());
				System.out.println("Quantity 	  		 :"+bean.getQuantity());
				System.out.println("Line TOtal           :"+bean.getLineTotal());
				
				break;
				
			case 2:
				System.exit(0);
				
				}
				
		
		
		
		
			}
		}
		
	}
	
	
	
					
				
	

	

		
	
		
					
					
		
		
		
		
		
		
		
		
		

