package com.cg.bsa.service;

import java.sql.SQLException;

import com.cg.bsa.bean.ProductBean;

public interface IProductService {

	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, Exception;

	public boolean insertSalesDetails(ProductBean bean) throws ClassNotFoundException, SQLException, Exception;

}
