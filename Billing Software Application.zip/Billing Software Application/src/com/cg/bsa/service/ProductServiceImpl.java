package com.cg.bsa.service;


import java.sql.SQLException;

import com.cg.bsa.bean.ProductBean;
import com.cg.bsa.dao.IProductDao;
import com.cg.bsa.dao.ProductDaoImpl;

public class ProductServiceImpl implements IProductService{

	IProductDao productDao=new ProductDaoImpl();
	
	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, SQLException, Exception {
		ProductBean productBean=new ProductBean();
		System.out.println("2");
		productBean=productDao.getProductDetails(productCode);
		return productBean;
	}

	@Override
	public boolean insertSalesDetails(ProductBean bean) throws ClassNotFoundException, SQLException, Exception {
		
		productDao.insertSalesDetails(bean);
		
		return false;
		
		
	}

}
