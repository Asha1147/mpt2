package com.cg.bsa.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.BeforeClass;

import org.junit.Test;

import com.cg.bsa.bean.ProductBean;
import com.cg.bsa.dao.ProductDaoImpl;

public class ProductDaoImplTest {
	
	static ProductDaoImpl dao;
	static ProductBean bean;
	
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new ProductDaoImpl();
		bean = new ProductBean();
		
	}

	

	@Test
	public void testGetProductDetails() throws ClassNotFoundException, SQLException, Exception {
		
		assertNotNull(dao.getProductDetails(bean.getProductCode()));
	}

	@Test
	public void testInsertSalesDetails() throws ClassNotFoundException, SQLException, Exception {
		assertNotNull(dao.insertSalesDetails(bean));
	}
	

}
