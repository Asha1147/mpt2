SQL> CREATE TABLE enquiry(
    enqryId Number Primary Key,
    firstName Varchar2(20),
    lastName varchar2(20),
    contactNo Number(10),
    domain varchar2(20),
    city varchar2(20));

Table created.

SQL> CREATE SEQUENCE enquiries
  2  MINVALUE 1001
  3  MAXVALUE 9999
  4  START WITH 1001
  5  INCREMENT BY 1
  6  NOCACHE;

Sequence created.