package com.capgemini.contactbook.dao;

public interface QueryMapper {
	
	public static final String ADD_ENQUIRY=	"insert into enquiry values(enquiries.nextval,?,?,?,?,?)";
    public static final String SHOW_ENQUIRY="select  enquiries.currval from enquiry";
    public static final String VIEW_ENQUIRY="select * from enquiry where enqryId=?";
}
