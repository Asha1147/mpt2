package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	
	
	Logger logger=Logger.getRootLogger();
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	
	
	
	

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		int queryResult=0;
		int enqryID=0;
		try {
			Connection connection=DBConnection.getConnection();
			Statement st=null;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			
		
			
			
				preparedStatement=connection.prepareStatement(QueryMapper.ADD_ENQUIRY);
				preparedStatement.setString(1,enqry.getfName());
				preparedStatement.setString(2,enqry.getIname());
				preparedStatement.setString(3,enqry.getContactNo());
				preparedStatement.setString(4,enqry.getpDomain());
				preparedStatement.setString(5,enqry.getpLocation());
				queryResult=preparedStatement.executeUpdate();
				st=connection.createStatement();
				resultSet=st.executeQuery(QueryMapper.SHOW_ENQUIRY);
				while(resultSet.next()) {
					enqryID =	(resultSet.getInt(1));
						
				
			}
				if(queryResult==0)
				{
					logger.error("Insertion failed ");
					throw new ContactBookException("Inserting details failed ");

				}
				else
				{
					logger.info("Details added successfully:");
					return enqryID;
				}
				
				
				
		}
			catch(Exception e) {
				System.out.println(e);
			}
			
			
			
	
		return enqryID;
		
		
		
		
		
		
		
		
		
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ClassNotFoundException, SQLException, Exception{ 

		
		Connection connection=DBConnection.getConnection();
		PreparedStatement st=null;
	
		int a=EnquiryID;
		EnquiryBean bean=new EnquiryBean();
		try
		{
		
		st=connection.prepareStatement(QueryMapper.VIEW_ENQUIRY);
		st.setInt(1, a);
		ResultSet resultSet = st.executeQuery();
	          
				while(resultSet.next())
				{
				bean.setEnqryId(resultSet.getInt(1));
				bean.setfName(resultSet.getString(2));
				bean.setIname(resultSet.getString(3));
				bean.setContactNo(resultSet.getString(4));
				bean.setpDomain(resultSet.getString(5));
				bean.setpLocation(resultSet.getString(6));
				//return bean;
				}
				
				if(resultSet==null)
				{
					
					logger.error("Retrieve failed ");
					throw new ContactBookException("retrieving details failed ");
					
					
				}
				else
				{
					logger.info("retrieved successfully:");
					return bean;
					
					
				}
		
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
					
			
			 return bean;
	
		
	}


}
