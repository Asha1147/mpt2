package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

import com.igate.contactbook.bean.EnquiryBean;

public class Client {
	
   static Scanner sc= new Scanner(System.in);
   static ContactBookService contactService=null;
   static ContactBookServiceImpl contactServiceImpl=null;
   static Logger logger = Logger.getRootLogger();
   public static void main(String[] args) {
	   PropertyConfigurator.configure("resources//log4j.properties");
	   EnquiryBean enquiryBean=null;
	   
	   int enqryID=0;
	   int option=0;
	   
	   while(true) {
		   
		   System.out.println();
			System.out.println();
			System.out.println("*************************Global Requirements***********************");
			System.out.println("Choose an operation");

			System.out.println("1.Enter Enquiry Details ");
			System.out.println("2.View Enquiry Details on Id");
			System.out.println("0.Exit");
			System.out.println("*****************************************");
			System.out.println("Please enter a choice:");
			
			
			try {
				
				option=sc.nextInt();
				
				switch (option) {
				case 1:
					while(enquiryBean==null) {
						enquiryBean=showEnquiryDeatils();
					}
					
					try {
						
						contactService = new ContactBookServiceImpl();
						enqryID = contactService.addEnquiry(enquiryBean);
						
						System.out.println("Thank you "+enquiryBean.getfName()+enquiryBean.getIname()+ " your Unique Id is"+enqryID+"   we will contact you shortly" );
				        
						
						
					}catch (ContactBookException contactException) {
						logger.error("exception occured", contactException);
	                	System.err.println("ERROR : "+ contactException.getMessage());
					} 
					finally {
						enqryID = 0;
						contactService = null;
						enquiryBean = null;
					}
					
				   break;
				case 2:
					
					System.out.println("Enter the enquiry No");
                    enqryID=sc.nextInt();
                      try {
              	        enquiryBean=new EnquiryBean();
              	        contactService=new ContactBookServiceImpl();
              	        contactServiceImpl=new ContactBookServiceImpl();
              	     enquiryBean= contactService.getEnquiryDetails(enqryID);
              	        
              		    System.out.println(enquiryBean);
              		  
              	        }
              catch(Exception e) {
              	System.err.println("error:"+e.getMessage());
              	
              }
					
					
					break;
					
				case 0:
					System.out.print("Thank you Selecting us");
					System.exit(0);
					break;
					
					
					
				default:
					System.out.println("Enter a valid choice");
					break;
				}
				
						
			}catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
					
		   
		   
		   
	   }
	   
}

private static EnquiryBean showEnquiryDeatils() {
	
	EnquiryBean enquiryBean = new EnquiryBean();;

	

	System.out.println("Enter First Name: ");
	enquiryBean.setfName(sc.next());

	System.out.println("Enter Last Name: ");
	enquiryBean.setIname(sc.next());
	
	System.out.println("Enter Contact Number:");
	enquiryBean.setContactNo(sc.next());
	
	System.out.println("Enter Preferred Domain:");
	enquiryBean.setpDomain(sc.next());
	
	System.out.println("Enter Preferred Location:");
	enquiryBean.setpLocation(sc.next());
	

	contactServiceImpl = new ContactBookServiceImpl();

	try {
		contactServiceImpl.isValidEnquiry(enquiryBean);
		return enquiryBean;
		
		
	} catch (ContactBookException contactException) {
		logger.error("exception occured", contactException);
		System.err.println("Invalid data:");
		System.err.println(contactException.getMessage() + " \n Try again..");
		System.exit(0);

	}
	return null;
	

}

}
