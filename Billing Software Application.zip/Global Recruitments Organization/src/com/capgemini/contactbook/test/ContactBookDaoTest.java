package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoTest {

	static ContactBookDaoImpl dao;
	static EnquiryBean enquiry;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new ContactBookDaoImpl();
		enquiry = new EnquiryBean();
	}

	@Test
	public void addEnquiry() throws ContactBookException {

		assertNotNull(dao.addEnquiry(enquiry));

	}

	
	

}
