package com.capgemini.contactbook.service;



import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{
   ContactBookDao contactDao;
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		contactDao=new ContactBookDaoImpl();	
		int contactSeq;
		contactSeq= contactDao.addEnquiry(enqry);
		return contactSeq; 
		
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ClassNotFoundException, SQLException, Exception {
		EnquiryBean bean=new EnquiryBean();
		contactDao=new ContactBookDaoImpl();	
		
		bean=contactDao.getEnquiryDetails(EnquiryID);
		return bean;
		
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(enqry.getContactNo());
		return phoneMatcher.matches();
		
		
	}
}


	/*public void validateContact(EnquiryBean enquiryBean) throws ContactBookException {
		List<String> validationErrors = new ArrayList<String>();

		*/
	/*	if(!(isValidFName(enquiryBean.getfName()))) {
			validationErrors.add("\n Donar Name should not be empty");
		}*/
	
		//Validating Phone Number
		/*if(!(isValidContactNumber(enquiryBean.getContactNo()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}*/
		
		/*if(!(isValidPreferredLocation(enquiryBean.getpLocation()))) {
			validationErrors.add("\n Location should not be empty");
		}
		

		if(!(isValidDomain(enquiryBean.getpDomain()))) {
			validationErrors.add("\n Domain should not be empty");
		}*/
		
		
		
		
	/*private boolean isValidDomain(String pDomain) {
		if(pDomain==null)
		return false;
		return false;
	}

	private boolean isValidPreferredLocation(String pLocation) {
		if(pLocation==null)
		return false;
		return false;
	}*/

	/*private boolean isValidContactNumber(String contactNo) {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(contactNo);
		return phoneMatcher.matches();
		
		
	}*/

	/*private boolean isValidFName(String fName) {
		if(fName==null)
		
		return false;
		return false;
	}*/


